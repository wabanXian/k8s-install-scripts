This file has moved to [https://github.com/kubernetes/community/blob/master/contributors/devel/mesos-style.md](https://github.com/kubernetes/community/blob/master/contributors/devel/mesos-style.md)
