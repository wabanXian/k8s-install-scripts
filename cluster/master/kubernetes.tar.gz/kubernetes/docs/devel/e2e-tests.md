This file has moved to [https://github.com/kubernetes/community/blob/master/contributors/devel/e2e-tests.md](https://github.com/kubernetes/community/blob/master/contributors/devel/e2e-tests.md)
