This file has moved to: https://kubernetes.io/docs/user-guide/logging/overview/


<!-- BEGIN MUNGE: GENERATED_ANALYTICS -->
[![Analytics](https://kubernetes-site.appspot.com/UA-36037335-10/GitHub/docs/getting-started-guides/logging.md?pixel)]()
<!-- END MUNGE: GENERATED_ANALYTICS -->
